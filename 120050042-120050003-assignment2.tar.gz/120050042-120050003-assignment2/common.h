// Transformer object required everywhere
extern transformer t;
